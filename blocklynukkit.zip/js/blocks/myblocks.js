Blockly.Blocks['nk'] = {
  init: function() {
    this.jsonInit({
      "message0": 'nk服务器实例',
      "args0": [
        {
          "type": "input_value",
          "name": "VALUE"
        }
      ],
      "output": "NukkitServer",
      "colour": 20,
      "tooltip": "返回nukkit的服务器实例",
      "helpUrl": "#"
    });
  }
};